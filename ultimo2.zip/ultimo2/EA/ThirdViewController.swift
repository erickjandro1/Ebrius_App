//
//  ThirdViewController.swift
//  EA
//
//  Created by MacBook on 3/14/19.
//  Copyright © 2019 DME. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    
    var count1 = 0
    var nivel1: Double = 0
    @IBOutlet weak var count1Label: UILabel!
    @IBAction func touchTarro(_ sender: UIButton) {
        count1 += 1
        count1Label.text = "\(count1)"
        nivel1 = Double(count1) * 36.20
    }

    var count2 = 0
    var nivel2: Double = 0
    @IBOutlet weak var count2Label: UILabel!
    @IBAction func touchButton2(_ sender: UIButton) {
        count2 += 1
        count2Label.text = "\(count2)"
        nivel2 = Double(count2) * 12.78
    }
    
    var count3 = 0
    var nivel3: Double = 0
    @IBOutlet weak var count3Label: UILabel!
    @IBAction func touchButton3(_ sender: UIButton) {
        count3 += 1
        count3Label.text = "\(count3)"
        nivel3 = Double(count3) * 17.028
    }
    
    var count4 = 0
    var nivel4: Double = 0
    @IBOutlet weak var count4Label: UILabel!
    @IBAction func touchButton4(_ sender: UIButton) {
        count4 += 1
        count4Label.text = "\(count4)"
        nivel4 = Double(count4) * 11.076
    }
    
    var count5 = 0
    var nivel5: Double = 0
    @IBOutlet weak var count5Label: UILabel!
    @IBAction func touchButton5(_ sender: UIButton) {
        count5 += 1
        count5Label.text = "\(count5)"
        nivel5 = Double(count5) * 14.7576
    }
    
    var count6 = 0
    var nivel6: Double = 0
    @IBOutlet weak var count6Label: UILabel!
    @IBAction func touchButton6(_ sender: UIButton) {
        count6 += 1
        count6Label.text = "\(count6)"
        nivel6 = Double(count6 ) * 12.78
    }
    
    var count7 = 0
    var nivel7: Double = 0
    @IBOutlet weak var count7Label: UILabel!
    @IBAction func touchButton7(_ sender: UIButton) {
        count7 += 1
        count7Label.text = "\(count7)"
        nivel7 = Double(count7) * 7.56
    }
    
    var count8 = 0
    var nivel8: Double = 0
    @IBOutlet weak var count8Lbel: UILabel!
    @IBAction func touchButton8(_ sender: UIButton) {
        count8 += 1
        count8Lbel.text = "\(count8)"
        nivel8 = Double(count8) * 43.2
    }
    
    var count9 = 0
    var nivel9: Double = 0
    @IBOutlet weak var count9Label: UILabel!
    @IBAction func touchButton9(_ sender: UIButton) {
        count9 += 1
        count9Label.text = "\(count9)"
        nivel9 = Double(count9) * 40.32
    }
    
    var count10 = 0
    var nivel10: Double = 0
    @IBOutlet weak var count10Label: UILabel!
    @IBAction func touchButton10(_ sender: UIButton) {
        count10 += 1
        count10Label.text = "\(count10)"
        nivel10 = Double(count10) * 11.928
    }

    var count11 = 0
    var nivel11: Double = 0
    @IBOutlet weak var count11Label: UILabel!
    @IBAction func touchButton11(_ sender: UIButton) {
        count11 += 1
        count11Label.text = "\(count11)"
        nivel11 = Double(count11) * 15.8928
    }
    
    var count12 = 0
    var nivel12: Double = 0
    @IBOutlet weak var count12Label: UILabel!
    @IBAction func touchButton12(_ sender: UIButton) {
        count12 += 1
        count12Label.text = "\(count12)"
        nivel12 = Double(count12) * 16.8
    }
    
    var count13 = 0
    var nivel13: Double = 0
    @IBOutlet weak var count13Label: UILabel!
    @IBAction func touchButton13(_ sender: UIButton) {
        count13 += 1
        count13Label.text = "\(count13)"
        nivel13 = Double(count13) * 9.6
    }
    
    var count14 = 0
    var nivel14: Double = 0
    @IBOutlet weak var count14Label: UILabel!
    @IBAction func touchButton14(_ sender: UIButton) {
        count14 += 1
        count14Label.text = "\(count14)"
        nivel14 = Double(count14) * 14.08
    }
    
    var count15 = 0
    var nivel15: Double = 0
    @IBOutlet weak var count15Label: UILabel!
    @IBAction func touchButton15(_ sender: UIButton) {
        count15 += 1
        count15Label.text = "\(count15)"
        nivel15 = Double(count15) * 20.8
    }
    
    var count16 = 0
    var nivel16: Double = 0
    @IBOutlet weak var count16Label: UILabel!
    @IBAction func touchButton16(_ sender: UIButton) {
        count16 += 1
        count16Label.text = "\(count16)"
        nivel16 = Double(count16) * 9.00
    }
    
    var count17 = 0
    var nivel17: Double = 0
    @IBOutlet weak var count17Label: UILabel!
    @IBAction func touchButton17(_ sender: UIButton) {
        count17 += 1
        count17Label.text = "\(count17)"
        nivel17 = Double(count17) * 13.20
    }
    
    var count18 = 0
    var nivel18: Double = 0
    @IBOutlet weak var count18Label: UILabel!
    @IBAction func touchButton18(_ sender: UIButton) {
        count18 += 1
        count18Label.text = "\(count18)"
        nivel18 = Double(count18) * 19.50
    }
    
    var count19 = 0
    var nivel19: Double = 0
    @IBOutlet weak var count19Label: UILabel!
    @IBAction func touchButton19(_ sender: UIButton) {
        count19 += 1
        count19Label.text = "\(count19)"
        nivel19 = Double(count19) * 9.6
    }
    
    var count20 = 0
    var nivel20: Double = 0
    @IBOutlet weak var count20Label: UILabel!
    @IBAction func touchButton20(_ sender: UIButton) {
        count20 += 1
        count20Label.text = "\(count20)"
        nivel20 = Double(count20) * 14.08
    }
    
    var count21 = 0
    var nivel21: Double = 0
    @IBOutlet weak var count21Label: UILabel!
    @IBAction func touchButton21(_ sender: UIButton) {
        count21 += 1
        count21Label.text = "\(count21)"
        nivel21 = Double(count21) * 20.8
    }
    
    var count22 = 0
    var nivel22: Double = 0
    @IBOutlet weak var count22Label: UILabel!
    @IBAction func touchButton22(_ sender: UIButton) {
        count22 += 1
        count22Label.text = "\(count22)"
        nivel22 = Double(count22) * 9.00
    }
    
    var count23 = 0
    var nivel23: Double = 0
    @IBOutlet weak var count23Label: UILabel!
    @IBAction func touchButton23(_ sender: UIButton) {
        count23 += 1
        count23Label.text = "\(count23)"
        nivel23 = Double(count23) * 13.20
    }
    
    var count24 = 0
    var nivel24: Double = 0
    @IBOutlet weak var count24Label: UILabel!
    @IBAction func touchButton24(_ sender: UIButton) {
        count24 += 1
        count24Label.text = "\(count24)"
        nivel24 = Double(count24) * 19.50
    }
    
    
    var Peso: Double = 0
    var alcoholPuro: Double = 0
        @IBOutlet weak var weigth: UITextField!
    @IBAction func prueba(_ sender: UIButton) {
        if let peso_str = Double(weigth.text!){
            Peso = peso_str * 0.7
             alcoholPuro = (nivel1 + nivel2 + nivel3 + nivel4 + nivel5 + nivel6 + nivel7 + nivel8 + nivel9 + nivel10 + nivel11 + nivel12 + nivel13 + nivel14 + nivel15 + nivel16 + nivel17 + nivel18 + nivel19 + nivel20 + nivel21 + nivel22 + nivel23 + nivel24)/Peso
            if(alcoholPuro <= 0.4){
                let aviso = UIAlertController(title: "\(Double (round(alcoholPuro*1000)/1000))", message: "Aun puedes conducir, el límite es 0.4", preferredStyle: .alert)
                let retryButton = UIAlertAction(title: "Salir", style: .default){ action in self.navigationController?.popToRootViewController(animated: true)}
                aviso.addAction(retryButton)
                self.present(aviso, animated: true, completion: nil)
                
            }else{
                let aviso2 = UIAlertController(title: "\(Double(round(alcoholPuro*1000)/1000))", message: "Rebasaste el límite, no es recomendable conducir, el límite es 0.4", preferredStyle: .alert)
                let retryButton = UIAlertAction(title: "Salir", style: .default){ action in
                    self.navigationController?.popToRootViewController(animated: true)
                }
                aviso2.addAction(retryButton)
                self.present(aviso2, animated: true, completion: nil)
            }
        }else{
            let alert = UIAlertController(title: "Error", message: "Porfavor introduce un peso en números", preferredStyle:UIAlertController.Style.alert)
            let retryButton = UIAlertAction(title: "Intentar de nuevo", style: .cancel, handler: nil)
            alert.addAction(retryButton)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
  
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    


}
