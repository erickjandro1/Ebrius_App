//
//  SecondViewController.swift
//  EA
//
//  Created by MacBook on 3/14/19.
//  Copyright © 2019 DME. All rights reserved.
//

import UIKit
import AVFoundation

class SecondViewController: UIViewController {
    
    var minutes = 1
    var timer = Timer()
    var audioPlayer = AVAudioPlayer()
    
    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var sliderOutlet: UISlider!
    @IBAction func slider(_ sender: UISlider) {
        
        minutes = Int(sender.value)
        label.text = String(minutes) + " Minutes"
    }
    
    
    @IBOutlet weak var startOutlet: UIButton!
    @IBAction func start(_ sender: Any) {
        timer = Timer.scheduledTimer(timeInterval: 60, target: self, selector: #selector(SecondViewController.counter), userInfo: nil, repeats: true)
        
        sliderOutlet.isHidden = true
        startOutlet.isHidden = true
    }
    
    @objc func counter(){
        minutes -= 1
        label.text = String(minutes) + " Minutes"
        
        if(minutes == 0){
            timer.invalidate()
            audioPlayer.play()
        }
        
    }
    
    
    @IBOutlet weak var stopOutlet: UIButton!
    @IBAction func stop(_ sender: Any) {
        timer.invalidate()
        minutes = 1
        sliderOutlet.setValue(1, animated: true)
        label.text = "1 Minutes"
        
        audioPlayer.stop()
        
        sliderOutlet.isHidden = false
        startOutlet.isHidden = false
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        do{
            let audioPath = Bundle.main.path(forResource: "alarm", ofType: ".mp3")
            try audioPlayer = AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath!))
        }catch{
            //ERROR
        }

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
