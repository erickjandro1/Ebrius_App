//
//  FourViewController.swift
//  EA
//
//  Created by MacBook on 3/14/19.
//  Copyright © 2019 DME. All rights reserved.
//

import UIKit

class FourViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    @IBAction func onOpenLink(_ sender: Any) {
        UIApplication.shared.open(URL (string: "https://www.bodegasalianza.com/catalogo/licores")! as URL, options: [:], completionHandler: nil)
    }
    
    
    @IBAction func onOpenLinkTwo(_ sender: Any) {
        UIApplication.shared.open(URL (string: "https://www.laeuropea.com.mx/categorias/promociones")! as URL, options: [:], completionHandler: nil)
    }
    
    
    @IBAction func onOpenLinkThree(_ sender: Any) {
        UIApplication.shared.open(URL (string: "https://www.superama.com.mx/catalogo/d-vinos-y-licores")! as URL, options: [:], completionHandler: nil)
    }
    
    
    @IBAction func onOpenLinkFour(_ sender: Any) {
        
        UIApplication.shared.open(URL(string: "https://super.walmart.com.mx/cerveza-vinos-y-licores/cat940184")! as URL, options: [:], completionHandler: nil)
    }
}
